package com.example.SOAPJAXWSServerRPC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapjaxwsServerRpcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapjaxwsServerRpcApplication.class, args);
	}

}
